# Bomberman: Escape Explosivo v4

Versión con mapas más cerrados y tipo laberinto.

## Cambios principales
- Se eliminó la semilla.
- Cada mapa se genera aleatoriamente.
- Los mapas tienen más paredes y corredores.
- Se redujeron mucho las zonas abiertas.
- Solo aparecen pequeñas cámaras ocasionales para evitar que todo sea un único pasillo.
- Se mantienen algunos cruces y rutas alternativas, pero el mapa conserva apariencia de laberinto.

## Bombas por dificultad
- Fácil: 8 bombas
- Normal: 14 bombas
- Difícil: 22 bombas

## Tamaños
- Pequeño: 15×9
- Mediano: 21×13
- Grande: 31×19

## Modelado
Estado: `(fila, columna, tieneLlave)`.

Acciones:
- Arriba
- Abajo
- Izquierda
- Derecha

Costos:
- Piso: 1
- Caja: 3
- Bomba: 4
- Explosión: 6

Objetivo:
Recoger la llave y llegar a la salida.

Heurística A*:
- Sin llave: Manhattan actual→llave + Manhattan llave→salida.
- Con llave: Manhattan actual→salida.

## Publicación
Sube `index.html` a la raíz de un repositorio y activa GitHub Pages:
Settings > Pages > Deploy from a branch > main > /(root).
